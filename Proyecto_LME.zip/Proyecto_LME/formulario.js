// Obtener los valores de los campos de texto
const pesoInput = document.getElementById('peso'); // Supongamos que el ID del campo de peso es "peso"
const estaturaInput = document.getElementById('estatura'); // Supongamos que el ID del campo de estatura es "estatura"

// Calcular el índice de masa corporal (IMC)
function calcularIMC() {
    const peso = parseFloat(pesoInput.value);
    const estatura = parseFloat(estaturaInput.value);

    if (!isNaN(peso) && !isNaN(estatura) && estatura > 0) {
        const imc = peso / (estatura ** 2);
        return imc.toFixed(2); // Redondear a 2 decimales
    } else {
        return 'Ingresa valores válidos para peso y estatura.';
    }
}

// Mostrar el resultado en la página web
const resultadoElement = document.getElementById('resultado'); // Supongamos que tienes un elemento con ID "resultado"

function mostrarResultado() {
    const imcCalculado = calcularIMC();
    resultadoElement.textContent = `Tu IMC es: ${imcCalculado}`;
}

// Event listener para el botón o cuando se cambian los valores
const calcularButton = document.getElementById('calcular'); // Supongamos que tienes un botón con ID "calcular"
calcularButton.addEventListener('click', mostrarResultado);
